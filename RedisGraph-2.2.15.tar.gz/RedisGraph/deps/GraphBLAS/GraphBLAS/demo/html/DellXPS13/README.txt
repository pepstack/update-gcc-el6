Results on a Dell XPS 13 9380 laptop.

Intel(R) Core(TM) i7-8565U CPU @ 1.80GHz (up to 4.6GHz),
16GB of RAM.  MATLAB R2019a.  Ubuntu 18.04.  GraphBLAS and
the mexFunction interface compiled with gcc 7.4.0.  The CPU
has 4 hardware cores, and 4 threads were used (the default
when running OpenMP inside MATLAB).

v310: output from GraphBLAS v3.1.0
v312: output from GraphBLAS v3.1.2 (draft, Nov 15, 2019)
v320: output from GraphBLAS v3.2.0 (Feb 20, 2020)

