Results on an NVIDIA DGX Station

Intel(R) Xeon(R) CPU E5-2698 v4 @ 2.20GHz.
256GB of RAM.  MATLAB R2018a.  Ubuntu 16.04.
GraphBLAS and the mexFunction interface compiled with gcc 5.4.0.
The CPU has 20 hardware cores, and 20 threads were used
(the default when running OpenMP inside MATLAB).

A GPU-accelerated GraphBLAS is in progress, but this
test did not use any of the four Volta V100 GPUs.

v310: output from GraphBLAS v3.1.0
v312: output from GraphBLAS v3.1.2 (draft, Nov 15, 2019)
v320: output from GraphBLAS v3.2.0 (draft, Feb 19, 2020)

