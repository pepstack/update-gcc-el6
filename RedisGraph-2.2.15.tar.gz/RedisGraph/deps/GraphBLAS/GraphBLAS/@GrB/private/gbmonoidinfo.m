function gbmonoidinfo (monoid, type)        %#ok

% SuiteSparse:GraphBLAS, Timothy A. Davis, (c) 2017-2020, All Rights Reserved.
% http://suitesparse.com   See GraphBLAS/Doc/License.txt for license.

error ('GrB:mex', 'mexFunction not found; use gbmake to compile GraphBLAS') ;

