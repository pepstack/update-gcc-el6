function fmt = fbest (i,k)
if (i == k)
    fmt = ' & {\\bf %6.1f }' ;
else
    fmt = ' &      %6.1f  ' ;
end
