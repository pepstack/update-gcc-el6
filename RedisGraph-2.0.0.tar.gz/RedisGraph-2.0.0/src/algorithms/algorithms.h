/*
* Copyright 2018-2019 Redis Labs Ltd. and Contributors
*
* This file is available under the Redis Labs Source Available License Agreement
*/

#ifndef _ALGORITHMS_H_
#define _ALGORITHMS_H_

#include "./all_paths.h"

#endif
