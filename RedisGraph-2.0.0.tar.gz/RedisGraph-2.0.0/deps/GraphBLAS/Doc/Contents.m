% SuiteSparse/GraphBLAS/Doc
%
% Files
%   dox_fix     - add escape characters to a string, for Doxygen
%   dox_headers - DOX_HEADERS: run this script in MATLAB before running 'make dox'
